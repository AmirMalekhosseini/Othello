import Project.*;

public class Main {
    public static void main(String[] args) {
        MyProject myProject = new MyProject();
    }
}