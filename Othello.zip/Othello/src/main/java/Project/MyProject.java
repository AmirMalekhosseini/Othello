package Project;

import OthelloGraphic.Game;

public class MyProject {

    public MyProject() {
        Game newGame = new Game();
    }

}
